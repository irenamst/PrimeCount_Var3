﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Result
    {

        /*
         * Complete the 'primeCount' function below.
         *
         * The function is expected to return an INTEGER.
         * The function accepts LONG_INTEGER n as parameter.
         */

        public static int primeCount(long n)
        {
            int result;
            int L = 100;
            bool[] flag = new bool[L + 1];
            for (int i = 4; i <= L; i += 2)
            {
                flag[i] = true;
            }
            for (int i = 3; i * i <= L; i += 2)
            {
                if (!flag[i])
                {
                    for (int j = 2 * i; j <= L; j += i)
                    {
                        flag[j] = true;
                    }
                }
            }
            List<long> limits = new List<long>();
            limits.Add(2);
            long t = 2;
            for (int i = 3; i <= L && t > 0; i += 2)
            {
                if (!flag[i])
                {
                    t *= i;
                    if (t > 0) { limits.Add(t); }
                }
            }

            int br = 0;
            for(int i=0; i<n; i++)
            {
                if(n>=limits[i] && n <limits[i+1])
                {
                    br++;

                }

                
            }
            result = br;
            return result;
        }

    }
    internal class Solution
    {
        static void Main(string[] args)
        {
            int q = Convert.ToInt32(Console.ReadLine().Trim());

            for (int qItr = 0; qItr < q; qItr++)
            {
                long n = Convert.ToInt64(Console.ReadLine().Trim());

                int result = Result.primeCount(n);

                
                Console.WriteLine(result);
            }
        }
    }
}
